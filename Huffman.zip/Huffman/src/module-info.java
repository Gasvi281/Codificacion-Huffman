/**
 * 
 */
/**
 * 
 */
module Huffman {
	requires java.desktop;
}
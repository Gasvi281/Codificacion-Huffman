package Huffman;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextPane;

import java.awt.Window.Type;
import javax.swing.ImageIcon;

public class Historial extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tableHisto;
	private Huffman huffman;
	private DefaultTableModel tableModel;

	public Historial(Huffman huffman, LinkedList<MensajesCodificados> mensajesCodificados) {
		this.huffman = huffman;

		initialice(mensajesCodificados);
	}

	public void initialice(LinkedList<MensajesCodificados> mensajesCodificados) {
		setType(Type.POPUP);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 692, 511);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(219, 219, 219));
		panel.setBounds(10, 11, 656, 50);
		contentPane.add(panel);

		JLabel lblNewLabel_2 = new JLabel("TITULO");
		lblNewLabel_2.setBounds(288, 11, 98, 28);
		panel.add(lblNewLabel_2);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(new Color(219, 219, 219));
		menuBar.setBounds(22, 11, 54, 33);
		panel.add(menuBar);

		JMenu mnMenu = new JMenu("");
		mnMenu.setBackground(new Color(219, 219, 219));
		mnMenu.setIcon(new ImageIcon(Historial.class.getResource("/Imagenes/2.png")));
		menuBar.add(mnMenu);

		JMenuItem mntmHistorial = new JMenuItem("Inicio");
		mntmHistorial.setFont(new Font("Monotxt_IV25", Font.BOLD, 12));
		mntmHistorial.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Inicio inter = new Inicio(huffman, mensajesCodificados);
				inter.setVisible(true);
				dispose();
			}
		});
		mntmHistorial.setIcon(new ImageIcon(Historial.class.getResource("/Imagenes/1.png")));
		mnMenu.add(mntmHistorial);

		tableModel = new DefaultTableModel(new Object[] { "Mensaje", "Caracteres", "Códigos", "Mensaje Codificado" },
				0);
		tableHisto = new JTable(tableModel);
		JScrollPane scrollPane = new JScrollPane(tableHisto);
		scrollPane.setBounds(10, 90, 656, 265);
		contentPane.add(scrollPane);

		actualizarTabla(mensajesCodificados);
	}

	public void actualizarTabla(LinkedList<MensajesCodificados> mensajesCodificados) {
		tableModel.setRowCount(0);
		for (MensajesCodificados mensaje : mensajesCodificados) {
			File file = new File(mensaje.getId());
			
			tableModel.addRow(new Object[] { "Mensaje " + file.getName(),
					mensaje.getCaracteres(), mensaje.getCodigosCaracteres(), mensaje.getMensajeCodificado() });
		}

		JTextArea textArea_Men = new JTextArea();
		textArea_Men.setBounds(211, 381, 455, 80);
		textArea_Men.setLineWrap(true); 
		textArea_Men.setWrapStyleWord(true); 
		contentPane.add(textArea_Men);
		
		JScrollPane scrollPane_2 = new JScrollPane(textArea_Men);
	    scrollPane_2.setBounds(211, 381, 455, 80);
	    contentPane.add(scrollPane_2);

		JButton btnDecode = new JButton("Decodificar ");
		btnDecode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selectedRow = tableHisto.getSelectedRow();
				if (selectedRow != -1) {

					String mensajeCodificado = tableModel.getValueAt(selectedRow, 3).toString();
					MensajesCodificados mensaje = mensajesCodificados.get(selectedRow);

					
                   try {
						NodoB cabezaArbol = mensaje.getRaices();

						String mensajeDecodificado = huffman.decode(cabezaArbol, mensajeCodificado);
					

						textArea_Men.setText("Mensaje original: " + mensajeDecodificado + "\n" + "Codificación: "
								+ mensajeCodificado);
                   }catch(EDecodificacion ex) {
                	   JOptionPane.showMessageDialog(null, ex.getMessage(),"Advertencia",JOptionPane.WARNING_MESSAGE);
                   }
				} else {
					JOptionPane.showMessageDialog(null, "Por favor, seleccione una fila para decodificar",
							"Advertencia", JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnDecode.setBounds(10, 376, 182, 23);
		btnDecode.setForeground(Color.BLACK);
		btnDecode.setFont(new Font("Monotxt_IV25", Font.BOLD, 12));
		btnDecode.setBackground(new Color(126, 143, 134));
		contentPane.add(btnDecode);

		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selectedRow = tableHisto.getSelectedRow();

				if (selectedRow != -1) {
					String mensaje= tableModel.getValueAt(selectedRow, 0).toString();
					String[] numero=mensaje.split(" ");
					huffman.eliminar(numero[1]);
					tableModel.removeRow(selectedRow);
				} else {
					JOptionPane.showMessageDialog(null, "Por favor, seleccione una fila para eliminar", "Advertencia",
							JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnEliminar.setForeground(new Color(255, 255, 255));
		btnEliminar.setBackground(new Color(204, 32, 36));
		btnEliminar.setBounds(41, 424, 118, 23);
		btnEliminar.setFont(new Font("Monotxt_IV25", Font.BOLD, 12));
		contentPane.add(btnEliminar);

	}
}
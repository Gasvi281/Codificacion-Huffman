package Huffman;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JInternalFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class Inicio extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldCodigo;
	private Huffman huffman;
	private LinkedList<MensajesCodificados> mensajesCodificados;
	private Historial historial;
	private String rutaArchivoSeleccionado;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					LinkedList<MensajesCodificados> mensajesCodificados = new LinkedList<>();
					Huffman huffman = new Huffman(mensajesCodificados);

					Inicio frame = new Inicio(huffman, mensajesCodificados);
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Inicio(Huffman huffman, LinkedList<MensajesCodificados> mensajesCodificados) {
		this.huffman = huffman;
		this.mensajesCodificados = mensajesCodificados;
		this.historial = new Historial(huffman, mensajesCodificados);
		initialize();
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				cerrarPrograma();
			}
		});
	}

	private void cerrarPrograma() {
		try {
			huffman.guardarFicheros();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "Error al guardar los mensajes codificados: " + e.getMessage());
		}
	}

	public void initialize() {

		setType(Type.POPUP);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 691, 462);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(193, 193, 193));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(20, 24, 645, 50);
		panel.setBackground(new Color(219, 219, 219));
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("TITULO");
		lblNewLabel_2.setBounds(266, 11, 98, 28);
		panel.add(lblNewLabel_2);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(new Color(219, 219, 219));
		menuBar.setForeground(new Color(192, 192, 192));
		menuBar.setBounds(22, 11, 54, 33);
		panel.add(menuBar);

		JMenu mnMenu = new JMenu("");
		mnMenu.setBackground(new Color(219, 219, 219));
		mnMenu.setIcon(new ImageIcon(Historial.class.getResource("/Imagenes/2.png")));
		menuBar.add(mnMenu);

		JMenuItem mntmHistorial = new JMenuItem("Historial");
		mntmHistorial.setFont(new Font("Monotxt_IV25", Font.BOLD, 12));
		mntmHistorial.setBackground(new Color(219, 219, 219));
		mntmHistorial.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Historial histo = new Historial(huffman, mensajesCodificados);
				histo.setVisible(true);
				dispose();

			}
		});
		mntmHistorial.setIcon(new ImageIcon(Historial.class.getResource("/Imagenes/1.png")));
		mnMenu.add(mntmHistorial);

		JTextArea textArea_Men = new JTextArea();
		textArea_Men.setBounds(24, 255, 485, 150);
		textArea_Men.setLineWrap(true); 
		textArea_Men.setWrapStyleWord(true); 
		contentPane.add(textArea_Men);
		
		JScrollPane scrollPane_2 = new JScrollPane(textArea_Men);
	    scrollPane_2.setBounds(24, 255, 485, 80);
	    contentPane.add(scrollPane_2);
		

		JButton btnCode = new JButton("Codificar");
		btnCode.setBounds(32, 177, 146, 29);
		btnCode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				 if (rutaArchivoSeleccionado == null) {
		                JOptionPane.showMessageDialog(null, "Seleccione un archivo antes de codificar.");
		                return;
		            }
				 File file= new File(rutaArchivoSeleccionado);
				 if(!file.getName().endsWith(".txt")) {
					 JOptionPane.showMessageDialog(null, "Seleccione un archivo de texto.");
					 return;
				 }

		            try {
		            	
		            	String contenido=huffman.getFicheros().readTexto(file.getName());
		                String textoParaCodificar = contenido.toString();
		                String binario = huffman.convertirStringABinario(textoParaCodificar);
						huffman.getFicheros().escribirTextoAUXILIAR(binario, file.getName());

		                
		                if (!textoParaCodificar.isEmpty()) {
		                    String mensajeCodificado = huffman.codificar(textoParaCodificar, file.getName());
		                    textArea_Men.setText(mensajeCodificado);

		                    huffman.guardarFicheros();
		                } else {
		                    JOptionPane.showMessageDialog(null, "El archivo está vacío.");
		                }
		            } catch (FileNotFoundException ex) {
		                JOptionPane.showMessageDialog(null, "Archivo no encontrado.");
		            } catch (IOException ex) {
		                JOptionPane.showMessageDialog(null, "Error al leer el archivo.");
		            } catch (ClassNotFoundException e1) {
		            	JOptionPane.showMessageDialog(null, "Error clase no encontrada");
					}

			}
		});
		btnCode.setFont(new Font("Monotxt_IV25", Font.BOLD, 12));
		btnCode.setForeground(new Color(0, 0, 0));
		btnCode.setBackground(new Color(126, 143, 134));
		contentPane.add(btnCode);

		JLabel lblNewLabel = new JLabel("Mensaje ");
		lblNewLabel.setBounds(24, 232, 177, 25);
		lblNewLabel.setFont(new Font("Century", Font.BOLD, 13));
		contentPane.add(lblNewLabel);

		JLabel lblIngreseElMensaje = new JLabel("Primero elija el mensaje y luego da click en Codificar\r\n");
		lblIngreseElMensaje.setBounds(24, 110, 397, 25);
		lblIngreseElMensaje.setFont(new Font("Century", Font.BOLD, 13));
		contentPane.add(lblIngreseElMensaje);
		
		JButton btnEligeMen = new JButton("Elegir Mensaje");
		btnEligeMen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 JFileChooser fc = new JFileChooser();
		            fc.setCurrentDirectory(new java.io.File("C:\\Users\\ADMIN\\Downloads\\Imagenes"));//cambia a la que creas mas conveniente usar 

		            FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de texto (*.txt)", "txt");
		            fc.setFileFilter(filter);

		            int op = fc.showOpenDialog(Inicio.this);

		            if (op == JFileChooser.APPROVE_OPTION) {
		                rutaArchivoSeleccionado = fc.getSelectedFile().getAbsolutePath();
		                JOptionPane.showMessageDialog(null, "Archivo seleccionado: " + rutaArchivoSeleccionado);
		            }}
		});
		btnEligeMen.setForeground(Color.BLACK);
		btnEligeMen.setFont(new Font("Monotxt_IV25", Font.BOLD, 12));
		btnEligeMen.setBackground(new Color(126, 143, 134));
		btnEligeMen.setBounds(22, 138, 179, 29);
		contentPane.add(btnEligeMen);

	}
}